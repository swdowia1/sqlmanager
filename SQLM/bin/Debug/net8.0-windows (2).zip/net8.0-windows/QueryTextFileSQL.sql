--EmailMessageContent: Wiadomości
select * from [Email].[EmailMessageContent] where MessageId=4195

--[Email].[TrackedLink]: Powiązane linki
select ec.Subject,et.LinkTemplate from [Email].[EmailMessageContent] ec
	join [Email].[TrackedLink] et on ec.Id=et.MessageContentId
	where ec.MessageId=4195

